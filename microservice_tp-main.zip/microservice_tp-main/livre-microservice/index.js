const express = require('express');
const { MongoClient } = require('mongodb')
const app = express()

app.use(express.json());
const client = new MongoClient('mongodb://127.0.0.1:27017')
let db;
client.connect().then(() => {
    db = client.db('dbClass')
    console.log('Connected!');
})
app.get('/livers', async(req, res) => {
    try {
        const livers = await db.collection('livers').find({}).toArray();
        res.status(200).json(livers)
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.get('/livers/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const liver = await db.collection('livers').findOne({ id: id });
        res.status(200).json(liver)
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.get('/livers/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const liver = await db.collection('livers').findOne({ id: id });
        if (!liver) {
            return res.status(404).json({ message: "Livre not found" })
        }
        res.status(200).json(liver)
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.post('/livres', async(req, res) => {
    try {
        const { titre, auteur, isbn } = req.body;
        const livers = await db.collection('livers').find({}).toArray();
        let id;

        id = livers.length == 0 ? 1 : livers[livers.length - 1].id + 1
        const liver = {
            id: id,
            titre,
            auteur,
            isbn,
            disponible: true,
            dateCreation: new Date().toISOString()
        }
        await db.collection('livers').insertOne(liver);

    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})

app.put('/livers/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const liver = await db.collection('livers').findOne({ id: id });
        if (!liver) {
            return res.status(404).json({ message: "Livre not found" })
        }
        const result = await db.collection('livers').replaceOne({ id: id }, { id, ...res.body, dateCreation: liver.dateCreation });
        if (result.matchedCount == 0) return res.status(404).json({ message: "Error" })
        res.status(200).json({ message: "Liver misAjour" })
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.patch('/livers/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const { disponible } = req.body;
        const result = await db.collection('livers').updateOne({ id: id }, { disponible });
        if (result.deletedCount == 0) return res.status(404).json({ message: "Error" })
        res.status(200).json({ message: "Liver deleted" })
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.delete('/livers/:id/desponabilete', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const result = await db.collection('livers').deleteOne({ id: id });
        if (result.deletedCount == 0) return res.status(404).json({ message: "Error" })
        res.status(200).json({ message: "Liver deleted" })
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})


app.listen(3001, () => {

    console.log("Livre service demarre sur le port 3001")
})