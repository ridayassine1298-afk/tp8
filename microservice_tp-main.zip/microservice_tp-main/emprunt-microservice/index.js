const express = require('express');
const { MongoClient } = require('mongodb')
const app = express()

app.use(express.json());
const client = new MongoClient('mongodb://127.0.0.1:27017')
let db;
client.connect().then(() => {
    db = client.db('dbClass')
    console.log('Connected!');
})
app.get('/emprunts', async(req, res) => {
    try {
        const emprunts = await db.collection('emprunts').find({}).toArray();
        res.status(200).json(emprunts)
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.get('/emprunts/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const emprunt = await db.collection('emprunts').findOne({ id: id });
        res.status(200).json(emprunt)
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})

app.post('/emprunts', async(req, res) => {
    try {
        const emprunts = await db.collection('emprunts').find({}).toArray();
        let id;

        id = emprunts.length == 0 ? 1 : emprunts[emprunts.length - 1].id + 1
        const emprunt = {
            id: id,
            ...res.body,
            dateCreation: new Date().toISOString()
        }
        await db.collection('emprunts').insertOne(emprunt);

    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})

app.put('/emprunts/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const emprunt = await db.collection('emprunts').findOne({ id: id });
        if (!emprunt) {
            return res.status(404).json({ message: "Emprunt not found" })
        }
        const result = await db.collection('emprunts').replaceOne({ id: id }, { id, ...res.body, dateCreation: emprunt.dateCreation });
        if (result.matchedCount == 0) return res.status(404).json({ message: "Error" })
        res.status(200).json({ message: "emprunt misAjour" })
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})
app.delete('/emprunts/:id', async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const result = await db.collection('emprunts').deleteOne({ id: id });
        if (result.deletedCount == 0) return res.status(404).json({ message: "Error" })
        res.status(200).json({ message: "emprunt deleted" })
    } catch (err) {
        return res.status(500).json({ message: err.message })
    }
})


app.listen(3003, () => {

    console.log("Emprunt service demarre sur le port 3003")
})